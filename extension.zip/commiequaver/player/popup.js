var i = document.getElementById("audio");
var d = document.getElementById('desc');
var p = document.getElementById('play');
var v = document.getElementById('volume');
var pos = document.getElementById('pos');
var element = document.body;
element.classList.add("pause");
d.stop();
  function togglePlay() {
    element.classList.toggle("pause");
    if (element.classList.contains("pause")) {
      i.pause();
      d.stop();
    } else {
      i.play();
      d.start();
    }
  }
  p.onclick = function () {
    document.getElementById('play').addEventListener('click', togglePlay);
  };
  volume.onchange = function () {
    i.volume = volume.value/100;
  }

  setInterval(function () {
    pos.value = i.currentTime;
  }, 1000);
  pos.onchange = function () {
    i.currentTime = pos.value;
  }
